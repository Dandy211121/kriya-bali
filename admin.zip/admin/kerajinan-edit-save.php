<?php
require_once __DIR__ . '/../config/db.php';
require_admin();
require_csrf();

$id = intval($_POST['id'] ?? 0);

if ($id <= 0) {
    die("ID tidak valid.");
}

$title       = trim($_POST['title'] ?? '');
$region_id   = intval($_POST['region_id'] ?? 0);
$category_id = intval($_POST['category_id'] ?? 0);
$artisan_id  = intval($_POST['artisan_id'] ?? 0);
$price       = intval($_POST['price'] ?? 0);
$desc        = trim($_POST['description'] ?? '');

// Ambil data lama
$old = db_fetch("SELECT * FROM crafts WHERE id = :id", ['id' => $id]);

if (!$old) {
    die("Data tidak ditemukan.");
}

// Upload foto baru
$image_path = $old['image_path'];

if (!empty($_FILES['image']['name'])) {

    $folder = "../public/uploads/crafts/";
    if (!is_dir($folder)) mkdir($folder, 0777, true);

    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $newName = time() . "-" . rand(1000, 9999) . "." . strtolower($ext);

    $destination = $folder . $newName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {

        // Hapus foto lama
        if (!empty($old['image_path'])) {
            $oldFile = "../" . $old['image_path'];
            if (file_exists($oldFile)) unlink($oldFile);
        }

        $image_path = "public/uploads/crafts/" . $newName;
    }
}

// Update database
db_exec("
    UPDATE crafts
    SET title = :t,
        region_id = :r,
        category_id = :c,
        artisan_id = :a,
        price = :p,
        description = :d,
        image_path = :img
    WHERE id = :id
", [
    't'   => $title,
    'r'   => $region_id,
    'c'   => $category_id,
    'a'   => $artisan_id,
    'p'   => $price,
    'd'   => $desc,
    'img' => $image_path,
    'id'  => $id
]);

header("Location: {$BASE_URL}admin/kerajinan-list.php?msg=updated");
exit;
