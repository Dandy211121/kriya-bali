<?php
require_once __DIR__ . '/../config/db.php';
require_admin();
require_csrf();

// Ambil data form
$name       = trim($_POST['name'] ?? '');
$region_id  = intval($_POST['region_id'] ?? 0);
$desc       = trim($_POST['description'] ?? '');

if ($name === '' || $region_id <= 0) {
    die("Input tidak valid.");
}

$photo_path = null;

// Upload foto jika ada
if (!empty($_FILES['image']['name'])) {

    $dir = __DIR__ . '/../public/uploads/artisans/';

    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    $newName = time() . '-' . rand(1000,9999) . '.' . $ext;

    $target = $dir . $newName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $photo_path = 'public/uploads/artisans/' . $newName;
    }
}

// Insert ke database
db_exec("
    INSERT INTO artisans (name, region_id, description, photo_path)
    VALUES (:n, :r, :d, :p)
", [
    'n' => $name,
    'r' => $region_id,
    'd' => $desc,
    'p' => $photo_path
]);

header("Location: pengrajin-list.php?added=1");
exit;
