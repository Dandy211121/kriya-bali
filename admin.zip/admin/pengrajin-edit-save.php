<?php
require_once __DIR__ . '/../config/db.php';
require_admin();
require_csrf();

$id = intval($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$region_id = intval($_POST['region_id'] ?? 0);
$desc = trim($_POST['description'] ?? '');

if ($id <= 0 || $name === '' || $region_id <= 0) {
    die("Input tidak valid.");
}

// Data lama
$old = db_fetch("
    SELECT * FROM artisans WHERE id = :id
", ['id' => $id]);

if (!$old) {
    die("Pengrajin tidak ditemukan.");
}

$photo_path = $old['photo_path'];

// Jika ada foto baru
if (!empty($_FILES['image']['name'])) {

    $dir = __DIR__ . '/../public/uploads/artisans/';

    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    $newName = time() . '-' . rand(1000, 9999) . '.' . $ext;

    $target = $dir . $newName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {

        // Hapus foto lama jika ada
        if (!empty($old['photo_path'])) {
            $oldFile = __DIR__ . '/../' . $old['photo_path'];
            if (file_exists($oldFile)) unlink($oldFile);
        }

        $photo_path = 'public/uploads/artisans/' . $newName;
    }
}

// Update database
db_exec("
    UPDATE artisans
    SET name = :n,
        region_id = :r,
        description = :d,
        photo_path = :p
    WHERE id = :id
", [
    'n'  => $name,
    'r'  => $region_id,
    'd'  => $desc,
    'p'  => $photo_path,
    'id' => $id
]);

header("Location: pengrajin-list.php?updated=1");
exit;
