<?php
require_once __DIR__ . '/../config/db.php';
require_admin();
require_csrf();

// Ambil data
$title       = trim($_POST['title'] ?? '');
$region_id   = intval($_POST['region_id'] ?? 0);
$category_id = intval($_POST['category_id'] ?? 0);
$artisan_id  = intval($_POST['artisan_id'] ?? 0);
$price       = intval($_POST['price'] ?? 0);
$desc        = trim($_POST['description'] ?? '');

// Validasi dasar
if ($title === '' || !$region_id || !$category_id || !$artisan_id || $price <= 0) {
    die("Input tidak valid.");
}

// Upload foto
$image_path = null;

if (!empty($_FILES['image']['name'])) {

    $folder = "../public/uploads/crafts/";
    if (!is_dir($folder)) mkdir($folder, 0777, true);

    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $newName = time() . "-" . rand(1000, 9999) . "." . strtolower($ext);

    $destination = $folder . $newName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
        $image_path = "public/uploads/crafts/" . $newName;
    }
}

// Simpan ke database
db_exec("
    INSERT INTO crafts (title, region_id, category_id, artisan_id, price, description, image_path)
    VALUES (:t, :r, :c, :a, :p, :d, :img)
", [
    't'   => $title,
    'r'   => $region_id,
    'c'   => $category_id,
    'a'   => $artisan_id,
    'p'   => $price,
    'd'   => $desc,
    'img' => $image_path,
]);

header("Location: {$BASE_URL}admin/kerajinan-list.php?msg=added");
exit;
